<?php

namespace join;

use pocketmine\event\Listener;
use pocketmine\plugin\PluginBase;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\event\player\PlayerQuitEvent;

class join extends PluginBase implements Listener{
public function onEnable() {
$this->getServer()->getPluginManager()->registerEvents ($this, $this);
}

public function 입장 (PlayerJoinEvent $event){
$event->setJoinMessage(false);
$p = $event->getPlayer();
$n = $p->getName();
$t = ("§e§l[§f§l 서버 알림§e§l ]§f§l ");
if (!($event->getPlayer()->hasPlayedBefore())){
$this->getServer()->broadcastMessage($t."{$n}§f§l님이 서버에 첫접속하였습니다. 환영해주세요.");
}
if (! $p->isOP()){
$this->getServer()->broadcastMessage($t."§b§l유저: {$n}§f§l님이 서버에 접속 했습니다.");
}
if ( $p->isOP()){
$this->getServer()->broadcastMessage($t."§6§l관리자: {$n}§f§l님이 서버에 접속하였습니다.");
}
}

public function 나가 (PlayerQuitEvent $event){
	$t = ("§e§l[§f§l 서버 알림§e§l ]§f§l ");
	$p = $event->getPlayer();
	$n = $p->getName();
	$event->setQuitMessage(false);
	if ( $p->isOP()){
		$this->getServer()->broadcastMessage($t."§6§l관리자: {$n}§f§l님이 퇴장 하셨습니다.");
		}
		if (! $p->isOP()){
		$this->getServer()->broadcastMessage($t."§b§l유저: {$n}§f§l님이 서버에서 퇴장하셨습니다.");
			}
		}
	}